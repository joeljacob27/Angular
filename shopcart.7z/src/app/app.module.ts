import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { DashboardComponent } from './modules/shop/components/dashboard/dashboard.component';
import { ProductComponent } from './modules/shop/components/product/product.component';
import { CartComponent } from './modules/shop/components/cart/cart.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    ProductComponent,
    CartComponent
  ],
  imports: [
    BrowserModule,
    AngularFontAwesomeModule,RouterModule,AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
