import { Injectable } from '@angular/core';
import { Product } from '../../shop/models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProdutService {

  private productList:Product[];
  
  //mocking he 
  constructor() {
    this.productList= [
      {
      "id": "2f27a562-91c9-4b2b-85a8-268cc9d53c93",
      "name": "Pork - Bones",
      "price": 394,
      "photo": "http://dummyimage.com/137x166.jpg/5fa2dd/ffffff"
    }, {
      "id": "62512e2a-fc34-4799-8641-b0b21fbe15c1",
      "name": "Ginger - Crystalized",
      "price": 437,
      "photo": "http://dummyimage.com/194x204.jpg/dddddd/000000"
    }, {
      "id": "0eb72656-1a67-4b9e-a2a9-cdec0bc3d51a",
      "name": "Mousse - Banana Chocolate",
      "price": 286,
      "photo": "http://dummyimage.com/161x164.jpg/dddddd/000000"
    }, {
      "id": "860dd9b2-0dee-49f4-8ddf-516e02034eb1",
      "name": "Wine - Harrow Estates, Vidal",
      "price": 494,
      "photo": "http://dummyimage.com/235x135.jpg/ff4444/ffffff"
    }, {
      "id": "b12e95b9-0764-46d1-93af-214bdb8e91b2",
      "name": "Tomatoes - Hot House",
      "price": 369,
      "photo": "http://dummyimage.com/166x100.jpg/ff4444/ffffff"
    }, {
      "id": "0648cd1a-396b-40cc-a559-724c8479e0bc",
      "name": "Muffin - Bran Ind Wrpd",
      "price": 309,
      "photo": "http://dummyimage.com/249x231.jpg/dddddd/000000"
    }, {
      "id": "0dce2c5e-4407-440e-a583-5bd1dc381af7",
      "name": "Wine - German Riesling",
      "price": 264,
      "photo": "http://dummyimage.com/184x214.jpg/dddddd/000000"
    }, {
      "id": "47c6107b-a751-4d3a-b7ae-9c510450c033",
      "name": "Tomatoes - Orange",
      "price": 356,
      "photo": "http://dummyimage.com/190x175.jpg/cc0000/ffffff"
    }, {
      "id": "56c3fdd6-87f8-4620-a05b-cc55afc335bd",
      "name": "Cookies - Englishbay Oatmeal",
      "price": 292,
      "photo": "http://dummyimage.com/201x171.jpg/cc0000/ffffff"
    }, {
      "id": "82302506-016c-4ca3-b59a-e708b35afce8",
      "name": "Lettuce - Green Leaf",
      "price": 435,
      "photo": "http://dummyimage.com/176x201.jpg/5fa2dd/ffffff"
    }];
   } // end of constructor


   //fetch all records
    fetchAll():Product[]{
      return this.productList;
    }

   //fetch by id
   fetchbyId(id:string):Product{
     return this.productList[this.getSelectedIndex(id)];

   }
   
  getSelectedIndex(id: string): any {
    //throw new Error("Method not implemented.");
    for(var i =0; i<this.productList.length; i++){
      if(this.productList[i].id == id){
        return i;
      }
    }
  }
}
