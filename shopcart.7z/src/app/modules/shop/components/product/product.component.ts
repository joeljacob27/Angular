import { Component, OnInit } from '@angular/core';
import { ProdutService } from 'src/app/modules/common/services/produt.service';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  
  private listProducts: Product[];

  constructor(private _ps:ProdutService) { }

  ngOnInit() {
  
    // In Angular7 subscribe happen at the background automatically
    this.listProducts = this._ps.fetchAll();
  }

}
