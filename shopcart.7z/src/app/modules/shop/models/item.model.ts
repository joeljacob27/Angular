import { Product } from './product.model';

//Basket or Cart items
export class Item{
    product:Product;
    quantity:number;
}